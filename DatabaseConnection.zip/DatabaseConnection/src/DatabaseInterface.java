

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class DatabaseInterface {

	public static DBAdministration db;
	private JFrame frame;
	private JTextField prename;
	private JTextField surname;
	private JTextField id;
	private JTextField id_update;
	private JTextField prename_update;
	private JTextField surname_update;
	private JTextField id_driver_job_done;
	private JTextField currentStreetDriver;
	private JTextField job_done;
	private JTextField Date;
	private JTextField Clock;
	private JTextField assignment;
	private JTextField street;
	private JTextField avenue;
	private JTextField currentAvenueDriver;
	
	 int[] home = new int[2];
	 private JTextField streetDeliver;
	 private JTextField avenueDeliver;
	 
	//DB Connection
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DatabaseInterface window = new DatabaseInterface();
					window.frame.setVisible(true);
					
					 int[] home = {50,50};
				     String url = "jdbc:mysql://132.199.139.24:3306/mmdb17_robertbosek?user=r.bosek&password=mmdb";
				     db = new DBAdministration(url, home);
				        
					} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public DatabaseInterface() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 560, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblManager = new JLabel("Manager");
		lblManager.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblManager.setBounds(10, 11, 72, 14);
		frame.getContentPane().add(lblManager);
		
		JLabel lblFahrer = new JLabel("Fahrer");
		lblFahrer.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblFahrer.setBounds(10, 152, 58, 14);
		frame.getContentPane().add(lblFahrer);
		
		JButton btnAuftragAnlegen = new JButton("Auftrag anlegen");
		btnAuftragAnlegen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnAuftragAnlegen.setBounds(10, 36, 161, 23);
		frame.getContentPane().add(btnAuftragAnlegen);
		
		//Fahrer einf�gen
		JButton btnInsertDriver = new JButton("Fahrer eintragen");
		btnInsertDriver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				int idDriver = Integer.parseInt(id.getText().toString());
				String[] driverName = new String[3];
				driverName [0] = prename.getText();
				driverName [1] = surname.getText();
				
				home[0] = Integer.parseInt(street.getText().toString()); 
				home[1] = Integer.parseInt(avenue.getText().toString());
				
				db.insertDriver(driverName);
				db.getAddressID(home);
				
				//Nach Eingabe der Daten, l�sche die Felder
				id.setText(null);
				prename.setText(null);
				surname.setText(null);	
			}
		});
		
		
		//Fahrer �ndern
		btnInsertDriver.setBounds(10, 70, 161, 21);
		frame.getContentPane().add(btnInsertDriver);
		JButton btnUpdateDriver = new JButton("Fahrer \u00E4ndern");
		
		btnUpdateDriver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				int idToUpdate = Integer.parseInt(id_update.getText().toString());
				String[] driverNameUpdate = new String[3];
				driverNameUpdate [0] = prename_update.getText();
				driverNameUpdate [1] = surname_update.getText();
				db.updateDriver(idToUpdate, driverNameUpdate);
				prename.setText(null);
				surname.setText(null);
			}
		});
		
		btnUpdateDriver.setBounds(10, 102, 161, 23);
		frame.getContentPane().add(btnUpdateDriver);
		
		//n�chsten Auftrag abrufen
		JButton btnGetNextAssignment = new JButton("n\u00E4chsten Auftrag abrufen");
		btnGetNextAssignment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
			}
		});
		btnGetNextAssignment.setBounds(7, 180, 164, 23);
		frame.getContentPane().add(btnGetNextAssignment);
		
		//Auftrag als erledigt markieren
		JButton btnAssignmentDelivered = new JButton("Auftrag erledigt");
		btnAssignmentDelivered.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int idDriverJobDone = Integer.parseInt(id_driver_job_done.getText().toString());
				db.finishedJob(idDriverJobDone);
				job_done.setText(db.finishedJob(idDriverJobDone));
			}
		});
		btnAssignmentDelivered.setBounds(7, 216, 164, 23);
		frame.getContentPane().add(btnAssignmentDelivered);
		
		prename = new HintTextField("Prename");
		prename.setBounds(242, 70, 86, 20);
		frame.getContentPane().add(prename);
		prename.setColumns(10);
		
		surname = new HintTextField("Surname");
		surname.setBounds(330, 70, 86, 20);
		frame.getContentPane().add(surname);
		surname.setColumns(10);
		
		id = new HintTextField("id");
		id.setBounds(181, 70, 59, 20);
		frame.getContentPane().add(id);
		id.setColumns(10);
		
		id_update = new HintTextField("id");
		id_update.setBounds(181, 103, 57, 20);
		frame.getContentPane().add(id_update);
		id_update.setColumns(10);
		
		prename_update = new HintTextField("New prename");
		prename_update.setBounds(250, 103, 86, 20);
		frame.getContentPane().add(prename_update);
		prename_update.setColumns(10);
		
		surname_update = new HintTextField("New surname");
		surname_update.setBounds(338, 103, 86, 20);
		frame.getContentPane().add(surname_update);
		surname_update.setColumns(10);
		
		id_driver_job_done = new HintTextField("id");
		id_driver_job_done.setBounds(190, 217, 52, 20);
		frame.getContentPane().add(id_driver_job_done);
		id_driver_job_done.setColumns(10);
		
		currentStreetDriver = new HintTextField("Current Str. Nr.");
		currentStreetDriver.setBounds(188, 181, 86, 20);
		frame.getContentPane().add(currentStreetDriver);
		currentStreetDriver.setColumns(10);
		
		job_done = new JTextField();
		job_done.setColumns(10);
		job_done.setBounds(250, 217, 128, 20);
		frame.getContentPane().add(job_done);
		
		Date = new HintTextField("Date");
		Date.setBounds(181, 37, 34, 20);
		frame.getContentPane().add(Date);
		Date.setColumns(10);
		
		Clock = new HintTextField("Clock");
		Clock.setBounds(219, 37, 39, 20);
		frame.getContentPane().add(Clock);
		Clock.setColumns(10);
		
		assignment = new HintTextField("Assignment Nr.");
		assignment.setBounds(256, 37, 54, 20);
		frame.getContentPane().add(assignment);
		assignment.setColumns(10);
		
		street = new HintTextField("Str. Nr");
		street.setBounds(413, 70, 53, 21);
		frame.getContentPane().add(street);
		street.setColumns(10);
		
		avenue = new HintTextField("Avenue Nr.");
		avenue.setBounds(462, 70, 72, 20);
		frame.getContentPane().add(avenue);
		avenue.setColumns(10);
		
		currentAvenueDriver = new HintTextField("Current Av. Nr.");
		currentAvenueDriver.setBounds(279, 181, 86, 20);
		frame.getContentPane().add(currentAvenueDriver);
		currentAvenueDriver.setColumns(10);
		
		streetDeliver = new HintTextField("Str. Nr.");
		streetDeliver.setBounds(320, 37, 58, 20);
		frame.getContentPane().add(streetDeliver);
		streetDeliver.setColumns(10);
		
		avenueDeliver = new HintTextField("Av. Nr.");
		avenueDeliver.setBounds(393, 37, 86, 20);
		frame.getContentPane().add(avenueDeliver);
		avenueDeliver.setColumns(10);
	}
}